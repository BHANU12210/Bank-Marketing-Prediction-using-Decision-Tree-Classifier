import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

# 📁 Ensure screenshots directory exists
os.makedirs("screenshots", exist_ok=True)

# 📥 Load the dataset (semicolon separated)
df = pd.read_csv("bank.csv", sep=';')
print("✅ Dataset loaded.")
print("🔹 Shape:", df.shape)
print("🔹 First 5 rows:\n", df.head(), "\n")

# 🔄 Encode categorical variables
label_encoders = {}
for col in df.select_dtypes(include=['object']).columns:
    le = LabelEncoder()
    df[col] = le.fit_transform(df[col])
    label_encoders[col] = le
print("✅ Categorical encoding complete.")

# 🎯 Features and target
X = df.drop("y", axis=1)
y = df["y"]

# 🔀 Train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
print("✅ Data split complete.")

# 🧠 Train Decision Tree model
model = DecisionTreeClassifier(random_state=42)
model.fit(X_train, y_train)
print("✅ Model trained.\n")

# 📊 Evaluation
y_pred = model.predict(X_test)
acc = accuracy_score(y_test, y_pred)
print(f"🎯 Accuracy: {acc}\n")
print("📋 Classification Report:\n", classification_report(y_test, y_pred))
print("🧮 Confusion Matrix:\n", confusion_matrix(y_test, y_pred))

# 📈 Feature Importance Plot
importances = model.feature_importances_
features = X.columns
indices = np.argsort(importances)

plt.figure(figsize=(10, 6))
plt.title("Feature Importances")
plt.barh(range(len(indices)), importances[indices], align="center")
plt.yticks(range(len(indices)), [features[i] for i in indices])
plt.xlabel("Relative Importance")
plt.tight_layout()
plt.savefig("screenshots/feature_importance.png")
plt.show()
print("📸 Feature importance screenshot saved to screenshots/feature_importance.png")
